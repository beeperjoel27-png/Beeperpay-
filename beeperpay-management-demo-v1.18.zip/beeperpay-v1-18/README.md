# Beeperpay Management Demo v1.18

This package extends the v1.17 management portal demonstration with:

- A role-permissions preview for Owner/Director and General Manager.
- A visual restriction of the Staff Activity tab to the Owner/Director preview.
- A session-only demo activity log for role switches and workspace navigation.
- Clear labels explaining that these are browser demonstrations, not backend security or a permanent audit trail.

## Deploy on GitHub Pages

1. Open the Beeperpay- repository on GitHub.
2. Open the `admin` folder.
3. Upload the replacement `index.html` from this package into that folder.
4. Commit with: `Upgrade management demo with permissions and audit preview v1.18`.
5. Open the existing management page URL and refresh it.

## Important safety boundary

This remains a static demonstration. It does not authenticate staff, enforce permissions on a server, store permanent audit records, connect to Supabase or a core banking provider, or move money. Do not enter real customer information. Real staff access requires backend authentication, server-side authorization, MFA, durable audit logging, and security testing.
