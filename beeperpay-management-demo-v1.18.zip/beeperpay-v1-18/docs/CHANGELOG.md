# v1.18 change log

- Added a role permissions matrix for the Owner/Director and General Manager previews.
- Hid the Staff Activity tab while the General Manager preview is selected.
- Added session-only audit events for role changes and navigation.
- Added a clear-audit control and HTML escaping for event text.
- Kept all live banking, transaction, and staff provisioning features disabled/unimplemented.
